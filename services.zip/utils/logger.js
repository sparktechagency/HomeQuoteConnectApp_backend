exports.log = (msg) => console.log(`[LOG]: ${msg}`);
exports.error = (msg) => console.error(`[ERROR]: ${msg}`);
