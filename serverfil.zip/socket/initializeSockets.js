// Update the main socket handler to include chat and authentication
const { socketHandler } = require('./socketHandler');
const chatHandler = require('./chatHandler');
const { verifyToken } = require('../utils/generateToken');

const initializeSocket = (io) => {
  // Authentication middleware for socket
// BEST VERSION - Works with Postman 100% (Headers + auth + query)
io.use(async (socket, next) => {
  try {
    let token = null;

    // 1. From auth object (Postman "Connection variables")
    token = socket.handshake.auth?.token;

    // 2. From Authorization header (Postman Headers tab)
    if (!token && socket.handshake.headers?.authorization) {
      const authHeader = socket.handshake.headers.authorization;
      if (authHeader.startsWith('Bearer ')) {
        token = authHeader.substring(7); // Remove "Bearer "
      } else {
        token = authHeader;
      }
    }

    // 3. From query param (Postman Params tab ?token=...)
    if (!token && socket.handshake.query?.token) {
      token = socket.handshake.query.token;
    }

    // If still no token → reject
    if (!token) {
      return next(new Error('Authentication error: No token provided'));
    }

    // Verify token
    const decoded = verifyToken(token);
    socket.userId = decoded.userId;
    socket.userRole = decoded.role;

    console.log(`Socket authenticated: ${decoded.userId} (${decoded.role})`);
    next();
  } catch (error) {
    console.log('Socket auth failed:', error.message);
    next(new Error('Authentication error: Invalid token'));
  }
});

  // Initialize handlers
  socketHandler(io);
  chatHandler(io);
};

module.exports = initializeSocket;